-- phpMyAdmin SQL Dump
-- version 4.0.10
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 30 2015 г., 02:12
-- Версия сервера: 5.5.38-log
-- Версия PHP: 5.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `daripodelu_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_catalogue`
--

CREATE TABLE IF NOT EXISTS `dpd_catalogue` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `uri` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_config`
--

CREATE TABLE IF NOT EXISTS `dpd_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `param` varchar(128) NOT NULL COMMENT 'Имя переменной',
  `value` text NOT NULL COMMENT 'Значение',
  `default` text NOT NULL COMMENT 'По умолчанию',
  `label` varchar(255) NOT NULL COMMENT 'Название',
  `type` varchar(64) NOT NULL COMMENT 'Тип',
  PRIMARY KEY (`id`),
  UNIQUE KEY `param` (`param`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `dpd_config`
--

INSERT INTO `dpd_config` (`id`, `param`, `value`, `default`, `label`, `type`) VALUES
(1, 'SITE_NAME', 'Дариподелу', 'Сайт', 'Название сайта', 'string'),
(2, 'SITE_ADMIN_EMAIL', 'ratmir85@gmail.com', 'ratmir85@gmail.com', 'E-mail администратора', 'string'),
(3, 'SITE_META_DESCRIPT', '', '', 'Meta Description', 'string'),
(4, 'SITE_META_KEYWORDS', '', '', 'Meta Keywords', 'string'),
(5, 'NEWS_ITEMS_PER_PAGE', '12', '8', 'Количество новостей на странице', 'integer'),
(6, 'NEWS_ITEMS_PER_HOME', '3', '3', 'Количество новостей на Главной странице', 'integer'),
(7, 'GATE_LOGIN', '22477_xmlexport', '', 'Логин от Gifts.ru', 'string'),
(8, 'GATE_PASSWORD', 'MF1lHzTR', '', 'Пароль от Gifts.ru', 'string');

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_filter`
--

CREATE TABLE IF NOT EXISTS `dpd_filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID фильтра',
  `name` varchar(30) NOT NULL COMMENT 'Название',
  `type_id` int(11) NOT NULL COMMENT 'ID типа фильтра',
  PRIMARY KEY (`id`),
  KEY `dpd_filter_fk0` (`type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_filter_type`
--

CREATE TABLE IF NOT EXISTS `dpd_filter_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_image`
--

CREATE TABLE IF NOT EXISTS `dpd_image` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `model` varchar(25) NOT NULL COMMENT 'Название модели',
  `ctg_id` int(11) DEFAULT NULL COMMENT 'ID категории',
  `owner_id` int(10) unsigned NOT NULL COMMENT 'ID владельца',
  `file_name` varchar(100) NOT NULL COMMENT 'Имя файла',
  `title` varchar(100) DEFAULT NULL COMMENT 'Заголовок файла',
  `description` varchar(255) DEFAULT NULL COMMENT 'Описание файла',
  `is_main` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Главное фото',
  `weight` int(11) NOT NULL COMMENT 'Приоритет',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Статус',
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_name` (`file_name`),
  KEY `ctg_id` (`ctg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_menu_tree`
--

CREATE TABLE IF NOT EXISTS `dpd_menu_tree` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `depth` int(11) NOT NULL COMMENT 'Уровень вложенности',
  `parent_id` int(11) NOT NULL COMMENT 'ID родительского узла',
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `alias` varchar(70) NOT NULL COMMENT 'Псевдоним',
  `module_id` varchar(40) DEFAULT NULL COMMENT 'Модуль',
  `controller_id` varchar(40) NOT NULL COMMENT 'Контроллер',
  `action_id` varchar(40) NOT NULL COMMENT 'Действие',
  `ctg_id` int(10) unsigned DEFAULT NULL COMMENT 'Категория',
  `item_id` int(10) unsigned DEFAULT NULL COMMENT 'Элемент',
  `can_be_parent` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Может иметь дочерние узлы',
  `show_in_menu` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Может быть пунктом меню',
  `show_as_link` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Отображать как ссылку',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'Статус',
  PRIMARY KEY (`id`),
  UNIQUE KEY `depth_alias` (`depth`,`alias`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `depth` (`depth`),
  KEY `alias` (`alias`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `dpd_menu_tree`
--

INSERT INTO `dpd_menu_tree` (`id`, `lft`, `rgt`, `depth`, `parent_id`, `name`, `alias`, `module_id`, `controller_id`, `action_id`, `ctg_id`, `item_id`, `can_be_parent`, `show_in_menu`, `show_as_link`, `status`) VALUES
(1, 1, 18, 0, 0, 'Корень сайта', '_root', NULL, 'controller', 'action', NULL, NULL, 1, 1, 1, 1),
(2, 2, 3, 1, 1, 'Каталог продукции', 'catalogue', NULL, 'catalogue', 'index', NULL, NULL, 1, 0, 1, 1),
(3, 4, 15, 1, 1, 'Методы нанесения', 'coating-methods', NULL, 'page', 'view', NULL, 1, 1, 1, 1, 1),
(4, 16, 17, 1, 1, '«Дари по делу»', 'dari-po-delu', NULL, 'page', 'view', NULL, 2, 1, 1, 1, 1),
(5, 5, 6, 2, 3, 'Шелкография', 'shelkografia', NULL, 'page', 'view', NULL, 3, 0, 1, 1, 1),
(6, 7, 8, 2, 3, 'Флекс', 'fleks', NULL, 'page', 'view', NULL, 4, 0, 1, 1, 1),
(7, 9, 10, 2, 3, 'Вышивка', 'vsivka', NULL, 'page', 'view', NULL, 5, 0, 1, 1, 1),
(8, 11, 12, 2, 3, 'Тампопечать', 'tampopecat', NULL, 'page', 'view', NULL, 6, 0, 1, 1, 1),
(9, 13, 14, 2, 3, 'УФ-печать', 'uf-pecat', NULL, 'page', 'view', NULL, 7, 0, 1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_migration`
--

CREATE TABLE IF NOT EXISTS `dpd_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dpd_migration`
--

INSERT INTO `dpd_migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1446809297),
('m130524_201442_init', 1446809305);

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_news`
--

CREATE TABLE IF NOT EXISTS `dpd_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `published_date` datetime NOT NULL COMMENT 'Дата публикации',
  `intro` text NOT NULL COMMENT 'Вводный текст',
  `content` mediumtext NOT NULL COMMENT 'Текст',
  `meta_title` varchar(255) DEFAULT NULL COMMENT 'META Title',
  `meta_description` varchar(255) DEFAULT NULL COMMENT 'META Description',
  `meta_keywords` varchar(255) DEFAULT NULL COMMENT 'META Keywords',
  `created_date` datetime NOT NULL COMMENT 'Дата создания',
  `last_update_date` datetime NOT NULL COMMENT 'Дата последнего обновления',
  `status` int(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Статус',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_page`
--

CREATE TABLE IF NOT EXISTS `dpd_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'IВ',
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `content` longtext NOT NULL COMMENT 'Содержимое',
  `meta_title` varchar(255) DEFAULT NULL COMMENT 'META Title',
  `meta_description` varchar(255) DEFAULT NULL COMMENT 'META Description',
  `meta_keywords` varchar(255) DEFAULT NULL COMMENT 'META Keywords',
  `last_update_date` datetime NOT NULL COMMENT 'Дата последнего обновления',
  `created_date` datetime NOT NULL COMMENT 'Дата создания',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Опубликовать',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Таблица предназначена для хранения содержимого статических с' AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `dpd_page`
--

INSERT INTO `dpd_page` (`id`, `name`, `content`, `meta_title`, `meta_description`, `meta_keywords`, `last_update_date`, `created_date`, `status`) VALUES
(1, 'Методы нанесения', '<p>Раздел на стадии разработки.</p>', '', '', '', '2015-11-10 19:22:07', '2015-11-09 17:28:04', 1),
(2, 'Дари по делу', '<p>Страница на стадии разработки.</p>', '', '', '', '2015-11-09 17:29:57', '2015-11-09 17:29:57', 1),
(3, 'Шелкография', '<p>Страница на стадии разработки</p>', '', '', '', '2015-11-10 19:41:30', '2015-11-10 19:41:30', 1),
(4, 'Флекс', '<p>Страница на стадии разработки.</p>', '', '', '', '2015-11-10 19:42:22', '2015-11-10 19:42:22', 1),
(5, 'Вышивка', '<p>Страница на стадии разработки.</p>', '', '', '', '2015-11-10 19:44:13', '2015-11-10 19:44:13', 1),
(6, 'Тампопечать', '<p>Страница на стадии разработки.</p>', '', '', '', '2015-11-10 19:45:04', '2015-11-10 19:45:04', 1),
(7, 'УФ-печать', '<p>Страница на стадии разработки.</p>', '', '', '', '2015-11-10 19:46:28', '2015-11-10 19:46:28', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_print`
--

CREATE TABLE IF NOT EXISTS `dpd_print` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_product`
--

CREATE TABLE IF NOT EXISTS `dpd_product` (
  `id` int(11) NOT NULL COMMENT 'ID товара',
  `main_product_id` int(11) NOT NULL DEFAULT '0' COMMENT 'ID родительского товара',
  `catalogue_id` int(11) NOT NULL COMMENT 'ID категории',
  `group_id` int(11) DEFAULT NULL COMMENT 'ID группы',
  `code` varchar(100) DEFAULT NULL COMMENT 'Артикул',
  `name` varchar(255) NOT NULL COMMENT 'Название',
  `product_size` varchar(255) NOT NULL COMMENT 'Размер',
  `matherial` varchar(255) NOT NULL COMMENT 'Материал',
  `small_image` varchar(255) DEFAULT NULL COMMENT 'Путь к файлу картинки 200х200',
  `big_image` varchar(255) DEFAULT NULL COMMENT 'Путь к файлу картинки 280х280',
  `super_big_image` varchar(255) DEFAULT NULL COMMENT 'Путь к файлу картинки 1000х1000',
  `content` text COMMENT 'Описание',
  `status_id` int(1) DEFAULT NULL COMMENT 'ID статуса',
  `status_caption` varchar(40) NOT NULL COMMENT 'Статус',
  `brand` varchar(60) NOT NULL COMMENT 'Бренд',
  `weight` float(9,2) NOT NULL COMMENT 'Вес',
  `pack_amount` int(11) DEFAULT NULL COMMENT 'Количество в упаковке',
  `pack_weigh` float(9,2) DEFAULT NULL COMMENT 'Вес упаковки',
  `pack_volume` float(9,2) DEFAULT NULL COMMENT 'Объем упаковки',
  `pack_sizex` float(8,1) DEFAULT NULL COMMENT 'Ширина упаковки',
  `pack_sizey` float(8,1) DEFAULT NULL COMMENT 'Высота упаковки',
  `pack_sizez` float(8,1) DEFAULT NULL COMMENT 'Глубина упаковки',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT 'Всего на складе',
  `free` int(11) NOT NULL DEFAULT '0' COMMENT 'Доступно для резервирования',
  `inwayamount` int(11) NOT NULL DEFAULT '0' COMMENT 'Всего в пути (поставка)',
  `inwayfree` int(11) NOT NULL DEFAULT '0' COMMENT 'Доступно для резервирования из поставки',
  `enduserprice` float(14,2) NOT NULL DEFAULT '0.00' COMMENT 'Цена End-User',
  `user_row` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Создан пользователем',
  PRIMARY KEY (`id`),
  KEY `dpd_product_fk0` (`catalogue_id`),
  KEY `dpd_product_mprod_id` (`main_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_product_attachment`
--

CREATE TABLE IF NOT EXISTS `dpd_product_attachment` (
  `product_id` int(11) NOT NULL COMMENT 'ID товара',
  `meaning` int(1) NOT NULL COMMENT 'Тип файла',
  `file` varchar(255) DEFAULT NULL COMMENT 'URL доп. файла',
  `image` varchar(255) DEFAULT NULL COMMENT 'URL доп. картинки',
  `name` varchar(255) DEFAULT NULL COMMENT 'Описание',
  KEY `dpd_product_attachment_fk0` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_product_filter`
--

CREATE TABLE IF NOT EXISTS `dpd_product_filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `filter_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dpd_product_filter_fk0` (`product_id`),
  KEY `dpd_product_filter_fk1` (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_product_print`
--

CREATE TABLE IF NOT EXISTS `dpd_product_print` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `print_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dpd_product_print_fk0` (`product_id`),
  KEY `dpd_product_print_fk1` (`print_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_seo`
--

CREATE TABLE IF NOT EXISTS `dpd_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `module_id` varchar(40) DEFAULT NULL COMMENT 'Модуль',
  `controller_id` varchar(40) NOT NULL COMMENT 'Контроллер',
  `action_id` varchar(40) NOT NULL COMMENT 'Действие',
  `ctg_id` int(11) DEFAULT NULL COMMENT 'Категория',
  `item_id` int(11) DEFAULT NULL COMMENT 'Элемент',
  `heading` varchar(255) DEFAULT NULL COMMENT 'Заголовок',
  `meta_title` varchar(255) DEFAULT NULL COMMENT 'META Title',
  `meta_description` varchar(255) DEFAULT NULL COMMENT 'META Description',
  `meta_keywords` varchar(255) DEFAULT NULL COMMENT 'META Keywords',
  PRIMARY KEY (`id`),
  UNIQUE KEY `i_mcaci` (`module_id`,`controller_id`,`action_id`,`ctg_id`,`item_id`),
  KEY `i_mca` (`module_id`,`controller_id`,`action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_session`
--

CREATE TABLE IF NOT EXISTS `dpd_session` (
  `id` char(40) NOT NULL,
  `expire` int(11) NOT NULL,
  `data` longblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expire` (`expire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dpd_session`
--

INSERT INTO `dpd_session` (`id`, `expire`, `data`) VALUES
('1q0d4qsmfebt06khitt8qmdgs4', 1447096477, 0x5f5f666c6173687c613a303a7b7d),
('2n55tl1rougbvnqaat6vnogqm2', 1447092542, 0x5f5f666c6173687c613a303a7b7d),
('3fqj2enraqqvm3lfhqoaslu3t1', 1446819213, 0x5f5f666c6173687c613a303a7b7d),
('6aq4sdce7hf6o5lc02e593d7r4', 1448563042, 0x5f5f666c6173687c613a303a7b7d),
('a5034ggimrkghuievtad85srp1', 1447090161, 0x5f5f666c6173687c613a303a7b7d),
('bljnkup77uhju7iofms5qfvel2', 1447008590, 0x5f5f666c6173687c613a303a7b7d),
('glhbr47jnkhjugj839qj7tpgi6', 1447186254, 0x5f5f666c6173687c613a303a7b7d),
('itc1jpeqi2cmcvir61if3fh0c0', 1447096476, 0x5f5f666c6173687c613a303a7b7d5f5f72657475726e55726c7c733a373a222f61646d696e2f223b5f5f69647c693a313b),
('j9sdrdoiksklk5dmjb2e6s2gc2', 1447186253, 0x5f5f666c6173687c613a303a7b7d5f5f69647c693a313b),
('k8pvf1j9tc04ocjlghiso6nb35', 1448399766, 0x5f5f666c6173687c613a303a7b7d5f5f69647c693a313b),
('l0mnvt41irkh0ssgkep9t1kuh1', 1448399767, 0x5f5f666c6173687c613a303a7b7d),
('mq44b6ivuo007fri6ielpmr7d3', 1446812772, 0x5f5f666c6173687c613a303a7b7d),
('oqg92pjd3ddha7al1b1g6q2td4', 1447008588, 0x5f5f666c6173687c613a303a7b7d5f5f69647c693a313b),
('r0o1ha9ns1tfv3pshi0ajqqe80', 1448744442, 0x5f5f666c6173687c613a303a7b7d5f5f69647c693a313b),
('ue53an7l0erq3ev9u3gd4nrm00', 1446819212, 0x5f5f666c6173687c613a303a7b7d5f5f69647c693a313b),
('vegr5omuu9kcdohjb3p2k3ra43', 1448745932, 0x5f5f666c6173687c613a303a7b7d);

-- --------------------------------------------------------

--
-- Структура таблицы `dpd_user`
--

CREATE TABLE IF NOT EXISTS `dpd_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `dpd_user`
--

INSERT INTO `dpd_user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'i-kGsiym5DPaCfvhz_cEfRSGnpWiNraS', '$2y$13$vGN/dE8cOpiyHuIhqnyZKeOJUsDstmFzGYGr6xnpLwD7ReHriW/KC', NULL, 'ratmir85@gmail.com', 10, 1446811328, 1446811328);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `dpd_filter`
--
ALTER TABLE `dpd_filter`
  ADD CONSTRAINT `dpd_filter_fk0` FOREIGN KEY (`type_id`) REFERENCES `dpd_filter_type` (`id`);

--
-- Ограничения внешнего ключа таблицы `dpd_product`
--
ALTER TABLE `dpd_product`
  ADD CONSTRAINT `dpd_product_fk0` FOREIGN KEY (`catalogue_id`) REFERENCES `dpd_catalogue` (`id`);

--
-- Ограничения внешнего ключа таблицы `dpd_product_attachment`
--
ALTER TABLE `dpd_product_attachment`
  ADD CONSTRAINT `dpd_product_attachment_fk0` FOREIGN KEY (`product_id`) REFERENCES `dpd_product` (`id`);

--
-- Ограничения внешнего ключа таблицы `dpd_product_filter`
--
ALTER TABLE `dpd_product_filter`
  ADD CONSTRAINT `dpd_product_filter_fk0` FOREIGN KEY (`product_id`) REFERENCES `dpd_product` (`id`),
  ADD CONSTRAINT `dpd_product_filter_fk1` FOREIGN KEY (`filter_id`) REFERENCES `dpd_filter` (`id`);

--
-- Ограничения внешнего ключа таблицы `dpd_product_print`
--
ALTER TABLE `dpd_product_print`
  ADD CONSTRAINT `dpd_product_print_fk0` FOREIGN KEY (`product_id`) REFERENCES `dpd_product` (`id`),
  ADD CONSTRAINT `dpd_product_print_fk1` FOREIGN KEY (`print_id`) REFERENCES `dpd_print` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
